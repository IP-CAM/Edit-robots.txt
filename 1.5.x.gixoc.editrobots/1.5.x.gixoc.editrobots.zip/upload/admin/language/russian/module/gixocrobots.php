<?php
// Heading
$_['heading_title']                = '<a href="https://gixoc.ru">GixOC.ru</a> - <b>Edit robots.txt / Редактирование robots.txt</b>';

// Text
$_['text_module']                  = 'Модули';
$_['text_success']	               = 'Файл robots.txt успешно сохранен!';

// Entry
$_['entry_create']                 = 'Создать';
$_['entry_clean']                  = 'Очистить';

// Error
$_['error_permission']             = 'У вас нет прав для управления модулем ' . $_['heading_title'] .'!';
?>