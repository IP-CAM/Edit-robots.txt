<?php
// Heading
$_['heading_title']                = '<a href="https://gixoc.ru">GixOC.ru</a> - <b>Edit robots.txt / Редактирование robots.txt</b>';
$_['text_title']                   = 'GixOC.ru - Edit robots.txt / Редактирование robots.txt';

// Text
$_['text_module']                  = 'Modules';
$_['text_success']	               = 'Success: File robots.txt saved successfully!';
$_['text_edit']                    = 'Edit';

// Entry
$_['entry_create']                 = 'Create';
$_['entry_clean']                  = 'Clean';

// Error
$_['error_permission']             = 'Warning: You do not have permission to modify module ' . $_['heading_title'] .'!';