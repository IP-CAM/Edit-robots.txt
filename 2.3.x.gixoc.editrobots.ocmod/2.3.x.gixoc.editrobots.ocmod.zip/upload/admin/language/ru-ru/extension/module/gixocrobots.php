<?php
// Heading
$_['heading_title']                = '<a href="https://gixoc.ru">GixOC.ru</a> - <b>Редактирование robots.txt / Edit robots.txt</b>';
$_['text_title']                   = 'GixOC.ru - Редактирование robots.txt / Edit robots.txt';

// Text
$_['text_module']                  = 'Модули';
$_['text_success']	               = 'Файл robots.txt успешно сохранен!';
$_['text_edit']                    = 'Редактирование';

// Entry
$_['entry_create']                 = 'Создать';
$_['entry_clean']                  = 'Очистить';

// Error
$_['error_permission']             = 'У вас нет прав для управления модулем ' . $_['heading_title'] .'!';